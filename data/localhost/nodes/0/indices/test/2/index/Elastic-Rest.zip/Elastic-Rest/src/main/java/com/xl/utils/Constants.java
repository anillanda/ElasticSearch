package com.xl.utils;

public class Constants {
	
	public static final String EMS_METRICS_ROWNUM="ems.metrics.rowNum";	
	public static final String EMS_METRICS_ROWSTART="ems.metrics.rowStart";
	public static final String EMS_METRICS_HEADERNAME="ems.metrics.headername";
	public static final String EMS_METRICS_CELLINDEX="ems.metrics.cellLastIndex";
	public static final String EMS_METRICS_CELLSTARTINDEX="ems.metrics.cellStartIndex";
	public static final String EMS_CSV_DATASEPERATOR="ems.csv.dataseperator";
	public static final String EMS_METRICS_CELLDATEFORMAT="ems.metrics.cellDateFormat";
	public static final String EMS_FILE_INPUTFILE="ems.file.inputfile";
	public static final String EMS_FILE_OUTPUTFILE="ems.file.outputfile";
	public static final String CONFIG_FILENAME="config.properties";	
	public static final String EMS_METRICS_ASOFCELLINDEX="ems.metrics.asofCellIndex";
	public static final String AS_OF_LITARAL="asof";
}
