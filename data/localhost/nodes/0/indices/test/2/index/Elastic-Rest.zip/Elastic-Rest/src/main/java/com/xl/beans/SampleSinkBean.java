/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.xl.beans;

/**
 *
 * @author anil
 */
public class SampleSinkBean {
    
    private String frYear,vpmod,projectName,projectWorktype,businessObjective;

    public String getFrYear() {
        return frYear;
    }

    public void setFrYear(String frYear) {
        this.frYear = frYear;
    }

    public String getVpmod() {
        return vpmod;
    }

    public void setVpmod(String vpmod) {
        this.vpmod = vpmod;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getProjectWorktype() {
        return projectWorktype;
    }

    public void setProjectWorktype(String projectWorktype) {
        this.projectWorktype = projectWorktype;
    }

    public String getBusinessObjective() {
        return businessObjective;
    }

    public void setBusinessObjective(String businessObjective) {
        this.businessObjective = businessObjective;
    }
    
    

    
}
